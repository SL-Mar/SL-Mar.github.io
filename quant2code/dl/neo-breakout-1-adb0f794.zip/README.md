# Neo-Breakout-1 Model Bundle

## What's Inside

| File | Description |
|------|-------------|
| `neo-breakout-1.joblib` | Trained LightGBM classifier (988 KB) |
| `neo-breakout-1.json` | Model card — metrics, parameters, training config |
| `execution-template.py` | QuantConnect algorithm template with triple confirmation logic |
| `README.md` | This file |

## Model Overview

**Neo-Breakout-1** is a LightGBM binary classifier that predicts:

> P(price rises >= 2% within the first 30 minutes of the next trading day)

Trained via walk-forward cross-validation (160 folds) on 393K five-minute bars across 30 biotech small-cap tickers (June 2025 – February 2026).

| Metric | Value |
|--------|-------|
| Mean AUC | 0.684 |
| Precision | 41.8% |
| Top-K Hit Rate | 31.0% |
| Last Fold AUC | 0.776 |
| Features | 30 |

## Loading the Model

```python
import joblib
import numpy as np

model = joblib.load("neo-breakout-1.joblib")

# features: numpy array of shape (n_samples, 30)
probabilities = model.predict_proba(features)[:, 1]
```

## Feature List (30 features, in order)

The model expects a feature vector with these 30 columns, computed from intraday 5-minute OHLCV bars:

### Microstructure
- `high_timing` — normalized time of daily high (0–1)
- `low_timing` — normalized time of daily low (0–1)
- `direction_changes` — count of consecutive bar direction reversals
- `intraday_kurtosis` — kurtosis of intraday 5-min returns

### Volume Profile
- `first_hour_vol_pct` — fraction of daily volume in first 60 min
- `last_hour_vol_pct` — fraction of daily volume in last 60 min
- `volume_slope` — linear regression slope of intraday volume
- `vwap_deviation` — close price deviation from VWAP (%)

### Price Action
- `body_ratio` — |close - open| / (high - low)
- `upper_shadow_ratio` — (high - max(open, close)) / (high - low)
- `lower_shadow_ratio` — (min(open, close) - low) / (high - low)
- `path_efficiency` — |close - open| / sum of absolute 5-min moves
- `open_gap` — (open - prev_close) / prev_close

### Multi-Day
- `momentum_5d` — 5-day return
- `momentum_10d` — 10-day return
- `momentum_20d` — 20-day return
- `daily_volatility` — std of daily returns (20d window)
- `atr_ratio` — ATR(14) / close
- `rsi_14` — 14-day RSI
- `dist_from_20d_high` — (close - 20d high) / 20d high
- `dist_from_20d_low` — (close - 20d low) / 20d low
- `avg_volume_20d` — 20-day average daily volume
- `volume_ratio` — today's volume / avg_volume_20d
- `intraday_range` — (high - low) / open
- `close_position` — (close - low) / (high - low)
- `prev_day_return` — previous day's return
- `prev_day_range` — previous day's intraday range
- `overnight_return` — (today's open - yesterday's close) / yesterday's close
- `bar_count` — number of 5-min bars in the day
- `avg_bar_range` — mean (high - low) across 5-min bars

## Execution Architecture

The model alone does not generate alpha — it must be paired with intraday confirmation filters. The execution template implements **triple confirmation**:

1. **Model selection** — ticker must be in the model's top-K predictions
2. **Volume spike** — current minute bar volume > 20x rolling 30-bar average
3. **Donchian breakout** — current bar high exceeds highest high of previous 15 bars

Exit: 5% take-profit or EOD liquidation at 3:55 PM ET.

### Critical Parameters

| Parameter | Value | Notes |
|-----------|-------|-------|
| `VOL_WINDOW` | 30 | **Must be 30, not 6** — VOL_WINDOW=6 produces losing results |
| `DONCHIAN_PERIOD` | 15 | Optimal from parameter sweep (SR 6.76) |
| `SPIKE_FACTOR` | 20.0 | Volume spike multiplier |
| `TAKE_PROFIT_PCT` | 0.05 | 5% take-profit |

## Usage

1. Build a feature pipeline that computes the 30 features from 5-minute OHLCV data
2. Run `model.predict_proba(features)[:, 1]` to get breakout probabilities
3. Take the top-K tickers by probability as daily candidates
4. Feed candidates into `execution-template.py` on QuantConnect
5. The algorithm handles intraday entry timing via volume + Donchian confirmation

## License

This model is sold for personal use. Do not redistribute.

## Support

Questions: contact@slmar.co
