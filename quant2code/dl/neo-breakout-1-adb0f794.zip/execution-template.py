# region imports
from AlgorithmImports import *
from collections import deque
# endregion


class NeoBreakout1Template(QCAlgorithm):
    """
    Neo-Breakout-1 Execution Template — ML candidates + Volume spike + Donchian breakout.

    Triple Confirmation Entry (all three must be true):
    1. Ticker in model's top-K candidates for the day
    2. Volume spike: current bar volume > SPIKE_FACTOR * rolling avg of previous VOL_WINDOW bars
    3. Donchian breakout: current bar high > highest high of previous DONCHIAN_PERIOD bars

    Exit: Take-profit OR EOD liquidation at 3:55 PM ET.

    INSTRUCTIONS:
    - Load neo-breakout-1.joblib in your pipeline to generate daily predictions
    - Replace CANDIDATES dict with your model's top-K output each day
    - Tune parameters below to match your risk profile

    Model: neo-breakout-1 (dbed260a) — LightGBM 30-min breakout classifier
    """

    # ── Replace with your model's daily predictions ──────────────────────
    # Format: {"TICKER": probability, ...}
    # Top-K candidates sorted by predicted breakout probability
    CANDIDATES = {
        "TICKER1": 0.70,
        "TICKER2": 0.60,
        "TICKER3": 0.55,
        # ... add your model's top-10 predictions here
    }

    # ── Strategy parameters ──────────────────────────────────────────────
    SPIKE_FACTOR = 20.0        # Volume must exceed rolling avg by this multiple
    VOL_WINDOW = 30            # Rolling window for volume average (CRITICAL: use 30, not 6)
    DONCHIAN_PERIOD = 15       # Lookback for Donchian channel breakout (optimal from sweep)
    TAKE_PROFIT_PCT = 0.05     # 5% take-profit target

    def initialize(self):
        self.set_start_date(2026, 1, 26)
        self.set_end_date(2026, 3, 28)
        self.set_cash(10000)

        self.live_mode_active = self.live_mode
        self.log(f"Algorithm initialized - Live Mode: {self.live_mode_active}")
        self.log(
            f"Triple Confirmation | Spike {self.SPIKE_FACTOR}x | "
            f"Donch {self.DONCHIAN_PERIOD} | VolWin {self.VOL_WINDOW} | "
            f"TP {self.TAKE_PROFIT_PCT:.0%} | Top {len(self.CANDIDATES)} candidates"
        )

        self.symbols = {}
        for ticker in self.CANDIDATES:
            try:
                eq = self.add_equity(ticker, Resolution.MINUTE)
                eq.set_data_normalization_mode(DataNormalizationMode.RAW)
                self.symbols[ticker] = eq.symbol
            except Exception as e:
                self.log(f"WARN: Could not add {ticker}: {e}")

        self._pos_size = 2000      # $ per position
        self._max_pos = 5          # max concurrent positions

        self._entry_prices = {}
        self._entered_today = {}
        self._exited_today = {}
        self._vol_buffers = {}
        self._high_buffers = {}
        self._day_initialized = None

        self._total_trades = 0
        self._wins = 0
        self._losses = 0
        self._tp_exits = 0
        self._eod_exits = 0
        self._pnl_list = []

        if self.symbols:
            first_symbol = list(self.symbols.values())[0]
            self.schedule.on(
                self.date_rules.every_day(),
                self.time_rules.before_market_close(first_symbol, 5),
                self._liquidate_eod,
            )

    def on_data(self, data):
        date_str = str(self.time.date())

        # Reset daily state
        if self._day_initialized != date_str:
            self._day_initialized = date_str
            self._entry_prices = {}
            self._entered_today = {}
            self._exited_today = {}
            self._vol_buffers = {}
            self._high_buffers = {}

        for ticker in self.CANDIDATES:
            if ticker not in self.symbols:
                continue
            symbol = self.symbols[ticker]
            if not data.contains_key(symbol) or data[symbol] is None:
                continue

            bar = data[symbol]
            price = float(bar.close)
            bar_high = float(bar.high)
            bar_vol = float(bar.volume)

            # Build rolling buffers
            if ticker not in self._vol_buffers:
                self._vol_buffers[ticker] = deque(maxlen=self.VOL_WINDOW)
            self._vol_buffers[ticker].append(bar_vol)

            if ticker not in self._high_buffers:
                self._high_buffers[ticker] = deque(maxlen=self.DONCHIAN_PERIOD + 1)
            self._high_buffers[ticker].append(bar_high)

            # ── Take-profit check for open positions ─────────────────
            if self._entered_today.get(ticker, False):
                if self.portfolio[symbol].invested and not self._exited_today.get(ticker, False):
                    entry = self._entry_prices.get(ticker, 0)
                    if entry > 0 and price >= entry * (1 + self.TAKE_PROFIT_PCT):
                        pnl_pct = (price - entry) / entry * 100
                        self._pnl_list.append(pnl_pct)
                        self._wins += 1
                        self._tp_exits += 1
                        self._exited_today[ticker] = True
                        self.liquidate(symbol, tag="TP EXIT")
                        self.log(
                            f"{date_str} {self.time.strftime('%H:%M')} "
                            f"{ticker} TP EXIT @ ${price:.2f} ({pnl_pct:+.1f}%)"
                        )
                continue

            # No new entries after 3 PM
            if self.time.hour >= 15:
                continue

            # ── Triple confirmation entry ────────────────────────────
            vol_buf = self._vol_buffers[ticker]
            high_buf = self._high_buffers[ticker]
            if len(vol_buf) < self.VOL_WINDOW or len(high_buf) <= self.DONCHIAN_PERIOD:
                continue

            # 1. Volume spike check
            prev_vols = list(vol_buf)[:-1]
            avg_vol = sum(prev_vols) / len(prev_vols) if prev_vols else 0
            if avg_vol <= 0 or bar_vol < avg_vol * self.SPIKE_FACTOR:
                continue

            # 2. Donchian breakout check
            prev_highs = list(high_buf)[:-1]
            donchian_upper = max(prev_highs[-self.DONCHIAN_PERIOD:])
            if bar_high <= donchian_upper:
                continue

            # 3. Position sizing and limits
            if price <= 0:
                continue
            active = sum(
                1 for t in self.CANDIDATES
                if t in self.symbols and self.portfolio[self.symbols[t]].invested
            )
            if active >= self._max_pos:
                continue
            shares = int(self._pos_size / price)
            if shares <= 0:
                continue

            # ── Enter position ───────────────────────────────────────
            self.market_order(symbol, shares)
            self._entry_prices[ticker] = price
            self._entered_today[ticker] = True
            self._total_trades += 1
            prob = self.CANDIDATES.get(ticker, 0)
            vol_ratio = bar_vol / avg_vol
            self.log(
                f"{date_str} {self.time.strftime('%H:%M')} {ticker} ENTRY: "
                f"{shares}sh @ ${price:.2f} | P={prob:.0%} | "
                f"vol={vol_ratio:.0f}x | high={bar_high:.2f} > donch={donchian_upper:.2f}"
            )

    def _liquidate_eod(self):
        """Exit all positions before market close."""
        date_str = str(self.time.date())
        for ticker in self.CANDIDATES:
            if self._exited_today.get(ticker, False):
                continue
            if ticker in self.symbols:
                symbol = self.symbols[ticker]
                if self.portfolio[symbol].invested:
                    price = float(self.securities[symbol].price)
                    entry = self._entry_prices.get(ticker, 0)
                    pnl_pct = (price - entry) / entry * 100 if entry > 0 else 0
                    self._pnl_list.append(pnl_pct)
                    if pnl_pct >= 0:
                        self._wins += 1
                    else:
                        self._losses += 1
                    self._eod_exits += 1
                    self.log(
                        f"{date_str} {self.time.strftime('%H:%M')} "
                        f"{ticker} EOD EXIT @ ${price:.2f} ({pnl_pct:+.1f}%)"
                    )
                    self.liquidate(symbol, tag="EOD EXIT")

    def on_end_of_algorithm(self):
        self.log("=" * 50)
        self.log("NEO-BREAKOUT-1 — TRIPLE CONFIRM + TP5% + EOD")
        self.log("=" * 50)
        self.log(f"Total trades: {self._total_trades} | TP: {self._tp_exits} | EOD: {self._eod_exits}")
        self.log(f"Wins: {self._wins} | Losses: {self._losses}")
        if self._total_trades > 0:
            self.log(f"Win rate: {self._wins / self._total_trades:.1%}")
        if self._pnl_list:
            avg = sum(self._pnl_list) / len(self._pnl_list)
            total = sum(self._pnl_list)
            self.log(f"Avg P&L: {avg:+.2f}% | Cumulative: {total:+.2f}%")

    def on_order_event(self, order_event):
        if order_event.status == OrderStatus.FILLED:
            self.log(
                f"FILLED: {order_event.symbol} "
                f"Qty={order_event.fill_quantity} "
                f"Price=${order_event.fill_price:.2f}"
            )
